# Deteccion de rostros y sus partes

import boto3

BUCKET = "test-fullstack"
KEY = "img_bolso.jpg"

def detect_faces(bucket, key, attributes=['ALL'], region="us-east-1"):
	rekognition = boto3.client("rekognition", region)
	response = rekognition.detect_faces(
	    Image={
			"S3Object": {
				"Bucket": bucket,
				"Name": key,
			}
		},
	    Attributes=attributes,
	)
	return response['FaceDetails']

for face in detect_faces(BUCKET, KEY):
    print("Face ({Confidence}%)".format(**face))

    # emotions
    for emotion in face['Emotions']:
        print("  {Type} : {Confidence}%".format(**emotion))

	# quality
    for quality, value in face['Quality'].items():
        print("  {quality} : {value}".format(quality=quality, value=value))


"""
	Expected output:
	Face (99.945602417%)
	  SAD : 14.6038293839%
	  HAPPY : 12.3668470383%
	  DISGUSTED : 3.81404161453%
"""