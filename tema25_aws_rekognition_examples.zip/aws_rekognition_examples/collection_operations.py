import boto3
from botocore.exceptions import ClientError
from os import environ

def create_collection(collection_id):

    client=boto3.client('rekognition')

    #Create a collection
    print('Creating collection:' + collection_id)
    response=client.create_collection(CollectionId=collection_id)
    print('Collection ARN: ' + response['CollectionArn'])
    print('Status code: ' + str(response['StatusCode']))
    print('Done...')
    

def list_collections():

    max_results=2
    
    client=boto3.client('rekognition')

    #Display all the collections
    print('\nDisplaying collections...')
    response=client.list_collections(MaxResults=max_results)
    collection_count=0
    done=False
    
    arr_collections = []
    while done==False:
        collections=response['CollectionIds']

        for collection in collections:
            arr_collections.append(collection)
            collection_count+=1
        if 'NextToken' in response:
            nextToken=response['NextToken']
            response=client.list_collections(NextToken=nextToken,MaxResults=max_results)
            
        else:
            done=True

    return arr_collections   


def list_faces_in_collection(collection_id):

    maxResults=20
    faces_count=0
    tokens=True

    client=boto3.client('rekognition')
    response=client.list_faces(CollectionId=collection_id,
                               MaxResults=maxResults)

    print('\nFaces in collection ' + collection_id)

 
    arr_faces = []
    while tokens:

        faces=response['Faces']

        for face in faces:
            arr_faces.append(face)
        if 'NextToken' in response:
            nextToken=response['NextToken']
            response=client.list_faces(CollectionId=collection_id,
                                       NextToken=nextToken,MaxResults=maxResults)
        else:
            tokens=False
    return arr_faces   
    

def delete_collection(collection_id):

    print('Attempting to delete collection ' + collection_id)
    client=boto3.client('rekognition')
    status_code=0
    try:
        response=client.delete_collection(CollectionId=collection_id)
        status_code=response['StatusCode']
        
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            print ('The collection ' + collection_id + ' was not found ')
        else:
            print ('Error other than Not Found occurred: ' + e.response['Error']['Message'])
        status_code=e.response['ResponseMetadata']['HTTPStatusCode']
    return(status_code)

def delete_faces_from_collection(collection_id, faces):

    client=boto3.client('rekognition')

    response=client.delete_faces(CollectionId=collection_id,
                               FaceIds=faces)
    
    print(str(len(response['DeletedFaces'])) + ' faces deleted:') 							
    for faceId in response['DeletedFaces']:
         print (faceId)
    return len(response['DeletedFaces'])


def main():

    collection_id='imgs_fs'

    # Remove collection
    #status_code=delete_collection(collection_id)
    #print('Status code: ' + str(status_code))


    # List collection
    arr_collections=list_collections()
    print("collections: " + str(len(arr_collections)))
    [print(collection) for collection in arr_collections]

    
    # Create collection
    if not collection_id in arr_collections:
        print("\n{}, just created...".format(collection_id))
        create_collection(collection_id)
    else:
        print("\n{}, already exists...".format(collection_id))
    
    # List faces from collection
    arr_faces=list_faces_in_collection(collection_id)
    [print(x) for x in arr_faces]
    print("faces count: " + str(len(arr_faces)))

    """
    # Delete faces from collection   
    faces=[]
    faces.append("c6b9fb0b-0cec-4126-bd87-ac6fe0f7da82")

    faces_count=delete_faces_from_collection(collection_id, faces)
    print("deleted faces count: " + str(faces_count))

    # List faces from collection
    arr_faces=list_faces_in_collection(collection_id)
    [print(x) for x in arr_faces]
    print("faces count: " + str(len(arr_faces)))
    """

if __name__ == "__main__":
    main()  